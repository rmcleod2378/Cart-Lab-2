"use strict";

const cartItems = {
    templateUrl: "app/app.html",

    controller: ["CartService", function(CartService){
        const vm = this;

        CartService.getAllItems().then(function(response){
            vm.cartList = response.data;
        });
        vm.addCartItems = function(newCartItems){
            CartService.addCartItems(newCartItems).then(function(response){
                vm.cartList = response.data;
            });
        };
        vm.deleteCartItems = function(id){
            CartService.deleteCartItems(id).then(function(response){
                vm.cartList = response.data;
            });
        };
        vm.editCartItems = function(cartItems){
            CartService.editCartItems(cartItems, newCartItems).then(function(response){
                vm.cartList = response.data;
            });
        };
    }]
}
angular
.module("App")
.component("cartItems", cartItems);