"use strict";

function CartService($http){
    const self = this;

    self.getAllItems = function(){
        return $http({
        method: "GET",
        url: "/cart-items"
        });
    };

        self.addCartItems = function(newCartItem){
            return $http({
                method: "POST",
                url: "/cart-items",
                data: {...newCartItem, price: Number(newCartItem.price), quantity: Number(newCartItem.quantity)}
            });
        };

        self.deleteCartItems = function(id){
            return $http({
                method: "DELETE",
                url: `/cart-items/${id}`
        });
    };

        self.editCartItems = function(cartItems, newCartItems){
            return $http({
                method: "PUT",
                url: `/cart-items/${item.id}`,
                data: item
            });
        };
}


angular
.module("App")
.service("CartService", CartService)